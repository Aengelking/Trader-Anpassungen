#ifndef __XHARBOUR__
Local oBrowse
#endif

SetColor( c_five )
art->( dbSeek( STR( bes->artikelnr, 6 ) ) )
cMe := Me(art->me)
NetUse("werkauf","wer",.F.,0)
NetUse("lagerne","lne",.F.,0)
NetUse("artlief","ali",.F.,0)
NetUse("lspos","lsp",.F.,0)
lsp->(dbSetOrder( 3 ))
NetUse("rechpos","rpos",.F.,0)
rpos->(dbSetOrder( 2 ))

NetUse("ls","ls",.F.,0)
bes->(dbPush())
@ 03,01 CLEAR TO 31,78
@ 03,01 TO 31,78

DevPos( 03, 01 )
DevOut( "��[        ]��[                         ]����������������������[Status:   ]�Ŀ" )
@ 03, 45 SAY "["+If(!bes->Printed,"nicht ","")+"gedruckt]"

@ 05, 03 SAY "Best-Nr..: [      /   ]    Bestellt.: [           ]    Auftragsbest�tigung"

DevPos( 06, 01 )
DevOut( "� Auftr-Nr.: [      /   ]    Geliefert: [           ]      [ ] [          ]  �" )
DevPos( 07, 01 )
DevOut( "�"+space(76)+"�" )
DevPos( 08, 01 )
DevOut( "� Bestelldatum...: [        ]                  Einkaufspreis..:   [        ] �" )
DevPos( 09, 01 )
DevOut( "� Liefertermin...: [    ]                      Preiseinheit...:       [    ] �" )


@ 10,03 SAY "Wunschtermin...: [    ]"
@ 10,21 SAY StrZero(bes->wterm)

@ 10,48 SAY "Rabatt.........:      [     ]"

//@ 11,03 SAY "Soll-Lieferung.: [        ]"
//@ 11,21 SAY bes->ldatum

@ 11,48 SAY "W�hrung........:          [ ]"
DevPos( 12, 01 )
DevOut( "� Letzte �nderung: [        ]                  W�hrungsfaktor.: [          ] �" )
DevPos( 13, 01 )
DevOut( "�"+space(76)+"�" )
DevPos( 14, 01 )
DevOut( "� Zahlungsart....: [ ]                         Bezugsschl�ssel: [ ]          �" )
DevPos( 15, 01 )
DevOut( "� Kontaktperson..: [                         ]")

DevPos( 16, 01 )
DevOut( "� Besteller......: [  ]"+space(36)+"[               ] �" )
/*DevPos( 17, 01 )
DevOut( "�"+space(76)+"�" )
DevPos( 18, 01 )
DevOut( "�"+space(76)+"�" )
DevPos( 19, 01 )
DevOut( "�"+space(76)+"�" )
DevPos( 20, 01 )
DevOut( "�"+space(76)+"�" )
DevPos( 21, 01 )
DevOut( "�"+space(76)+"�" )
DevPos( 22, 01 )
DevOut( "�"+space(76)+"�" )
DevPos( 23, 01 )
DevOut( "������������������������������������������������������������������������������" )*/
DevPos( 03, 04 )
DevOut( bes->liefma )
DevPos( 03, 16 )
DevOut( bes->matchcode )
DevPos( 03, 73 )
DevOut( bes->bestat )


@ 04, 03 SAY art->artikel
ali->(dbSetORder(2))
If ali->(dbSeek( bes->liefma+art->Matchcode ))
	@ 04,40 SAY ali->ArtLief
Endif

DevPos( 05, 15 )
DevOut( bes->besnr )
DevPos( 05, 22 )
DevOut( bes->posnr )
DevPos( 05, 42 )
DevOut( bes->beqty )
DevPos( 06, 15 )
DevOut( bes->aufabnr )
DevPos( 06, 22 )
DevOut( bes->aufitmnr )
DevPos( 06, 42 )
DevOut( bes->gelqty )
DevPos( 06, 61 )
DevOut( bes->confirmed )
DevPos( 06, 65 )
DevOut( bes->abnr )
DevPos( 08, 21 )
DevOut( bes->besda )
DevPos( 08, 68 )
DevOut( bes->ekpr )
@ 09, 21 SAY StrZero(bes->lterm)
DevPos( 09, 72 )
DevOut( bes->pe )

DevPos( 10, 71 )
DevOut( bes->rabatt )
DevPos( 11, 75 )
DevOut( bes->money )

DevPos( 12, 21 )
DevOut( bes->lastrem )

DevPos( 12, 66 )
DevOut( bes->rate )
DevPos( 14, 21 )
DevOut( bes->pay )
DevPos( 14, 66 )
DevOut( bes->code )
//DevPos( 15, 21 )
//DevOut( bes->person )

@ 15,48 SAY "Zugang ohne RG.: "+LTrim(Transform(bes->zoqty,cMe))

DevPos( 16, 21 )
DevOut( bes->buyer )
DevPos( 16, 61 )
DevOut( bes->grund )



SetColor( c_five )
If bes->person != 0
	ku->( dbSetOrder( 1 ) )
	ku->( dbSeek( bes->liefma + "L" ) )
	@ 15,21 SAY Pad(GetContact(bes->person)["name"],25)
Endif
//if(bes->person <> 0,EVAL({|| , QQOUT(ALLTRIM( MACRO("ku->person"+if( bes->person=1,"",LTRIM( STR( bes->person,1 ) ) ) ) )) }),"")
DevPos( 16, 24 )
Buy( bes->buyer, .F. )

oBrowse := oBrowse2 := NIL
IF bes->BeQty < 0 //Belastungsanzeige
   NetUse("lagerne","lne")
   lne->(dbSetORder(7))
   IF bes->GelQty != 0 .AND. lne->(dbSeek( "BE"+Str(bes->Besnr,6)+Str(bes->Posnr,3) ))
   	oBrowse := lne->(TBrowseTr():New(20,02,30,38))
   	oBrowse:lBox := .F.
   	oBrowse:WhileBlock := {|| lne->RefTyp == "BE" .AND. lne->RefBeleg == bes->Besnr .AND. lne->Refpos == bes->Posnr }
   	oBrowse:NewColumn(Pad("Datum",8)+" "+Pad("Beleg",6)+" "+PadL("Menge",12)+Space(9),{|| DToC(lne->Datum)+" "+Str( lne->Nummer, 6)+" "+PadL(Transform(lne->Menge,cMe),12)+Space(9)})
   	oBrowse:AddKey(27,{|| .F. })
   	oBrowse:Display()
      @ 19,02 SAY t("R�cklieferungen")
   ENDIF
ELSEIf /*bes->GelQty != 0 .AND.*/ lsp->(dbSeek( Str(bes->Besnr,6)+Str(bes->Posnr,3) ))
	oBrowse := lsp->(TBrowseTr():New(20,02,30,38))
	oBrowse:lBox := .F.
	oBrowse:WhileBlock := {|| lsp->Besnr == bes->Besnr .AND. lsp->Bespos == bes->Posnr }
	oBrowse:NewColumn(Pad("Datum",8)+" "+Pad("Beleg",15)+" "+PadL("Menge",12),{|| ls->(dbSeek( lsp->Liefma+lsp->Beleg )),DToC(ls->Datum)+" "+lsp->Beleg+" "+PadL(Transform(lsp->Menge,cMe),12)})
	oBrowse:AddKey(27,{|| .F. })
	oBrowse:Display()
	@ 19,02 SAY "Lieferungen"

Endif
If /*(bes->GelQty != 0 .OR. ! art->Lagerart) .AND.*/ rpos->(dbSeek( Str(bes->Besnr,6)+Str(bes->Posnr,3) ))
	oBrowse2 := rpos->(TBrowseTr():New(20,39,30,77))
	oBrowse2:lBox := .F.
	oBrowse2:WhileBlock := {|| rpos->Besnr == bes->Besnr .AND. rpos->Posnr == bes->Posnr }
	oBrowse2:NewColumn(Pad("Datum",8)+" "+Pad("Beleg",15)+" "+PadL("Menge",12),{|| DToC(rpos->Date)+" "+rpos->Beleg+" "+PadL(Transform(rpos->Menge,cMe),12)})
	oBrowse2:AddKey(27,{|| .F. })
	oBrowse2:Display()

	@ 19,40 SAY IF(bes->BeQty*bes->EkPr<0,"Gutschriften","Rechnungen")
Endif

lWait := .T.
wer->(dbSetOrder(6)) //Besnr
if wer->(dbSeek(Str(bes->besnr,6)))
   @ 31,01 CLEAR TO 36,78
   @ 31,01 TO 36,78
   @ 31,01 SAY Chr(195)
   @ 31,78 SAY Chr(180)

	@ 32,03 SAY "Werksattsauftr.: "+LTrim(Str(wer->aufno))
	art->(dbSeek( Str(wer->Artno,6) ))
	@ 33,03 SAY "Fertigteil: "+LTrim(Str(wer->Artno))
	@ 34,03 SAY art->Matchcode
	@ 35,03 SAY Pad(art->Artikel,30)
	aMenu := {"Werkstattsauftrag bearbeiten"}

	lne->(dbSetOrder(1))
	If wer->Status < 3 .OR. ! lne->(dbSeek(wer->LagNum))
		@ 33,21 SAY "Ware nicht versandt"
	Else
		If lne->Packed
//			@ 18,52 SAY "Ware versandt"
			lDummy := .F.
			//@ 33,21 SAY "Sendung verfolgen" COLOR c_two
			Aadd(aMenu,"Sendung verfolgen")
         /*Do While SInkey(0) != 27
				If LastKey() == 13
					Einfug(0,wer->Lagnum,.F.,.F.)
				Endif
			Enddo*/
			lWait := .F.
		Else
			@ 33,21 SAY "Ware im Versand"
		Endif
	Endif
	nChoice := 1
	DO WHILE nChoice != 0
     nChoice := AChoice(32,48,33,77,aMenu)
     IF nChoice == 1
        aEnv := SaveEnv()
        __KeyBoard(Str(wer->Aufno)+Chr(13))
        WerkAuf()
        RestEnv(aEnv,.T.)
     ELSEIF nChoice == 2
          Einfug(0,wer->Lagnum,.F.,.F.)
     ENDIF
   ENDDO
Endif

lBr := ValType(oBrowse) == "O"
lBr2 := ValType(oBrowse2) == "O"
nKey := 0
If  lBr .OR. lBr2
	lWait := .F.
	@ 18,52 SAY Space(25)
	IF lBr
      oBrowse:Display()
   ENDIF
   IF lBr2
      oBrowse2:Display()
   ENDIF
	while (!lBr .OR. ! oBrowse:lExit)  .AND. (!lBr2 .OR. ! oBrowse2:lExit)
		if (!lBr .OR. oBrowse:stable) .AND. (! lBr2 .OR. oBrowse2:stable)
			Do While nKey == 0 .AND. (!lBr .OR. ! oBrowse:lExit)  .AND. (!lBr2 .OR. ! oBrowse2:lExit)
				nKey := Inkey(0) //A_INKEY(0.1)
			Enddo
			IF lBr
			   oBrowse:Event({nKey})
			ENDIF
			IF lBr2
			   oBrowse2:Event({nKey})
			ENDIF
			nKey := 0
		else
      	IF lBr
            oBrowse:Display()
         ENDIF
         IF lBr2
            oBrowse2:Display()
         ENDIF
		endif
	enddo
//	oBrowse:EventLoop()
Endif

If lWait
	Sinkey(0)
Endif