NetUse("englsre","re",.F.,0)
re->(dbSetOrder(10))

NetUse("engkund","ku",.F.,0)
ku->(dbSeek(auf->Kundma+"K"))

NetUse("me","me",.F.,0)

NetUse("ups","ups",.F.,0)
ups->(dbSetOrder(3))

SetColor( c_five )

art->( dbSeek( STR( auf->artikelnr, 6 ) ) )
nOrder := wer->(dbSetOrder(3))
wer->( dbSeek( Str( auf->Abnr,6 )+ Str(auf->Itmnr,3) ))
wer->(dbSetOrder(nOrder))
@ 03,01 CLEAR TO 23,78
@ 03,01 TO 23,78
DevPos( 03, 01 )
DevOut( "��["+auf->kundma+"]��["+auf->matchcode+"]����������������������[Status:   ]�Ŀ" )

DevPos( 05, 01 )
DevOut( "� AB-Nr....: [      /   ]    Bestellt.: [           ]  Kundenauftragsnummer  �" )
DevPos( 06, 01 )
DevOut( "� Best.-Nr.: [      /   ]    Geliefert: [           ]  [                  ]  �" )

@ 08,03 SAY "Auftragsdatum...: "+DToC(auf->besda)
lCallOff := Right(Str(auf->dterm,4),2) == "99"
If ! lCallOff
	@ 09,03 SAY "Liefertermin....: "+If(ku->JustInTime,DToC(auf->BDatum),NiceWeek( auf->dterm ))
	@ 10,03 SAY "Wunschtermin....: "+If(ku->JustInTime,DToC(auf->WDatum),NiceWeek(auf->wterm,4))
	If ku->JustInTime
		@ 11,03 SAY "Versandtag......: "+DToC(GetJITLiefertag(auf->BDatum,ku->JIT_LZ))
	Endif
Else
	@ 09,03 SAY "Rahmenende......: "+NiceWeek(auf->wterm,4)
	@ 10,03 SAY "Mindestbestand..: [ "+Transform(auf->MinStock,Me(art->me))+"]"
Endif

@ 12,03 SAY "Bearbeiter......:"; Buy( auf->buyer, .F. )
@ 13,03 SAY "Genehmigung.....:"

oAuftrag := Auftrag():New()
oAuftrag:Load(auf->Abnr)
lWaitApproval := .F.
nRec := NIL
lApproved :=  IsApproved("AUF",auf->Abnr,StoT(oAuftrag:LastChange),@lWaitApproval,@nRec)
IF ! lApproved
   @ 13,21 SAY If(!lWaitApproval,"nicht ","")+"angefordert"
   bDisplayApr := {|| .T. }
ELSE
   apr->(dbGoTo(nRec))
   //IF auf->Buyer != apr->ApprovedBy
      @ 13,21 SAY Trim(Buy(apr->ApprovedBy,.T.))+" "+Left(TtoC(StoT(apr->ApprovedDa)),17)
   /*ELSE
      @ 13,21 SAY t("nicht ben�tigt")
   ENDIF*/
   bDisplayApr := {||
      apr->(dbGoTo(nRec))
      cScreen := SaveScreen()
      @ 14,21 CLEAR TO 24,50
      @ 14,21 TO 24,50
      cReason := ""
      DO WHILE apr->Type == "AUF" .AND. apr->No == oAuftrag:AbNr
         cReason := Trim(Buy(apr->ApprovedBy,.T.))+" "+Left(TtoC(StoT(apr->ApprovedDa)),17)+Chr(13)+Chr(10)+apr->Reason+Chr(13)+Chr(10)+cReason
         apr->(dbSkip(-1))
      ENDDO
      MemoEdit(cReason,15,22,23,49,.F.)
      RestScreen(,,,,cScreen)
   }
ENDIF

If auf->Person > 0
	@ 14,03 SAY "Kontaktperson...: "+GetContact(auf->person)["name"]
Endif

@ 15,03 SAY    "Gedruckt........: "+Left(TtoC(SToT(oAuftrag:LastPrint)),17)


DevPos( 03, 16 )
DevOut( auf->matchcode )
DevPos( 03, 73 )
DevOut( auf->bestat )
DevPos( 04, 03 )
DevOut( art->artikel )
DevPos( 05, 15 )
DevOut( auf->abnr )
DevPos( 05, 22 )
DevOut( auf->itmnr )
DevPos( 05, 42 )
DevOut( auf->vkqty )
DevPos( 06, 15 )
DevOut( auf->besbesnr )
DevPos( 06, 22 )
DevOut( auf->besposnr )
DevPos( 06, 42 )
DevOut( auf->gelqty )
DevPos( 06, 57 )
DevOut( auf->aufnr )

@ 08,47 SAY "Verkaufspreis...: "+Ltrim(Str( auf->vkpr,8,2 ))+ " "+Currate(auf->money,"X")
@ 09,47 SAY "Preiseinheit....: "+Ltrim(Str( auf->pe ))
@ 10,47 SAY "Rabatt..........: "+Ltrim(Str(auf->rabatt,8,2))+"%"
If Select("wer")>0.AND.wer->Aufno != 0
	@ 11,47 SAY "Werkstattsautrag: "+Ltrim(Str(wer->Aufno))
Endif

//@ 12,47 SAY "Gedruckt am....: "+DToC(auf->LastPrint)

SetColor( c_five )

hStatus := {"    "=>"unbearbeitet","PRIN"=>"in Bearbeitung","ZOLL"=>"Zoll angemeldet","COLL"=>"Abholung angemeldet","PICK"=>"in Bearbeitung"}

bState := {|nInvoice| aEnv := SaveEnv(),re->(dbSetOrder(12)),re->(dbseek(Str(nInvoice,6)+Str(0,3))),cState := re->state,RestEnv(aEnv),If(!re->packed,hStatus[cState],"")}



re->(dbSeek( Str(auf->Abnr,6)+Str(auf->itmnr,3) ))
Do While re->abnr == auf->abnr .AND. re->reposnr == auf->itmnr .AND. re->aoqty == 0
	re->(dbSkip())
Enddo
If trVer >= "5.018"  .AND. re->abnr == auf->abnr .AND. auf->itmnr == re->reposnr
	oBrowse := re->(TBrowseTr():New(16,03,22,77))

	oBrowse:NewColumn( "Rechn. Datum    "+Pad("Menge",11)+" "+"Versand", {||	;
		Str(re->Rechnr,6)+" "+DtoC(re->Rechdat)+" "+Transform(re->aoqty,me->(Me(art->me)))+" "+art->me+" "+;
		Pad(If(ups->(dbSeek( Str(re->Rechnr,10) )),DToC(ups->datum),Eval(bState,re->Rechnr)),19) })

 	oBrowse:lBox := .F.
 	oBrowse:lArrow := .F.
  	oBrowse:WhileBlock := {|| re->abnr == auf->abnr .AND. re->reposnr == auf->itmnr}
  	oBrowse:ForBlock := {|| re->aoqty != 0 }
  	oBrowse:bRestFun := {|| .F. }
  	oBrowse:AddKey(13,{|| __KeyBoard(Chr(13)),If(ups->(dbSeek( Str(re->Rechnr,10) )),Einfug(re->Rechnr),Eval({||__KeyBoard(Chr(13)+Chr(13)),RechCha(re->Rechnr)})),.T. })
   oBrowse:AddKey(Asc("B"),bDisplayApr)
   oBrowse:AddKey(Asc("b"),bDisplayApr)
   oBrowse:goTop()

  	oBrowse:EventLoop()
Else
   DO WHILE .T.
      nKey := Sinkey(0)
      IF Chr(nKey) $ "Bb"
         Eval(bDisplayApr)
      ELSE
         EXIT
      ENDIF
   ENDDO

Endif

