//ANGEBOT
LOCAL nRec

NetUse("engauf","auf",.F.,0)
auf->(dbSetOrder( 6 )) //kundma+matchcode

NetUse("notes","note",.F.,0)

SetColor( c_five )
dbPush()
art->(dbSetOrder( 2 ))
art->( dbSeek( STR( ang->artikelnr, 6 ) ) )
ku->( dbSetOrder( 1 ) )
ku->( dbSeek( ang->kundma + "K" ) )

@ 04,01 CLEAR TO MaxRow(),63



//DevPos( 04, 01 )
//DevOut( "��[        ]��[                         ]�[Status:   ]����Ŀ" )
@ 05,03 SAY "Kunde..........: "+ku->Name1
@ 06,20 SAY ku->Town
@ 07,03 SAY "Artikel........: "+ang->matchcode
@ 08,20 SAY ang->artikel

@ 09,03 SAY "Datum..........: "+DToC(ang->besda)

@ 10,03 SAY "Bearbeiter.....:"
Buy( ang->buyer, .F. )
@ 11,03 SAY "Genehmigung....:"

lWaitApproval := .F.
nRec := NIL
lApproved :=  IsApproved("ANG",ang->Angnr,StoT(ang->LastChange),@lWaitApproval,@nRec)
bDisplayApr := {|| .T. }
IF ! lApproved
   @ 11,20 SAY If(!lWaitApproval,"nicht ","")+"angefordert"
ENDIF
IF ! Empty(nRec)
   apr->(dbGoTo(nRec))
   IF ang->Buyer != apr->ApprovedBy
      IF lApproved
         @ 11,20 SAY Trim(Buy(apr->ApprovedBy,.T.))+" "+Left(TtoC(StoT(apr->ApprovedDa)),17)
      ENDIF
      nAprRec := apr->(Recno())
      bDisplayApr := {||
         apr->(dbGoTo(nRec))
         cScreen := SaveScreen()
         @ 14,21 CLEAR TO 24,50
         @ 14,21 TO 24,50
         apr->(dbGoTo(nAprRec))
         cReason := ""
         DO WHILE apr->Type == "ANG" .AND. apr->No == ang->Angnr
            cReason := Trim(Buy(apr->ApprovedBy,.T.))+" "+Left(TtoC(StoT(apr->ApprovedDa)),17)+Chr(13)+Chr(10)+apr->Reason+Chr(13)+Chr(10)+cReason
            apr->(dbSkip(-1))
         ENDDO
         MemoEdit(cReason,15,22,23,49,.F.)
         RestScreen(,,,,cScreen)
      }
   ELSE
      @ 11,20 SAY t("nicht ben�tigt")
   ENDIF
ENDIF

@ 12,03 SAY "Kontaktperson..: "+GetContact(ang->person)["name"]



//DevPos( 04, 53 )
//DevOut( ang->bestat )
//DevPos( 14, 01 )
//DevOut( "� Bezugsschl�ssel:                                       �" )
//DevPos( 14, 21 )
//DevOut( ang->code )



cMatchcode := ang->Matchcode
nArtnr := ang->Artikelnr
nAngnr := ang->angnr
nMinQty := ang->VkQty
nRec := ang->(Recno())
//ang->(dbSkip())
art->( dbSeek( STR( ang->artikelnr, 6 ) ) )

nX := 1
nT := 15

@ nT,03 SAY "Menge"
@ nT,20 SAY "Preis "+Currate(ang->money,"X")
@ nT,30 SAY "PE"
@ nT,34 SAY "Rabatt"
@ nT,42 SAY "Lieferzeit"
Do While ang->Matchcode == cMatchcode .AND. ang->Angnr == nAngnr
   ang->(dbSkip(-1))
ENDDO
ang->(dbSkip())
Do While ang->Matchcode == cMatchcode .AND. ang->Angnr == nAngnr  .AND. nX <= MaxRow()-6-17
//
	art->( dbSeek( STR( nArtnr, 6 ) ) )
	@ nT+nX,01 CLEAR TO nT+nX,63
	@ nT+nX,03 SAY Transform(ang->VkQty,Me(art->me))
	@ nT+nX,Col()+1 SAY art->me
	@ nT+nX,21 SAY ang->vkpr
	@ nT+nX,30 SAY LTrim(Str(ang->PE))
	@ nT+nX,34 SAY LTrim(Str(ang->rabatt))
    @ nT+nX,42 SAY If(ang->dterm == 0,"ab Lager",LTrim(Str(ang->dterm))+" Wochen")
    nMinQty := Min(nMinQty,ang->VkQty)
	ang->(dbSkip())
	art->( dbSeek( STR( ang->artikelnr, 6 ) ) )
	nX++
Enddo

ang->(dbGoto(nRec))
art->( dbSeek( STR( nArtnr, 6 ) ) )
@ 13,03 SAY "Bestellt am....: "
@ 13,20 SAY "x" COLOR "N/R*"
bWhile := {|| ! auf->(Eof()) .AND. auf->Kundma == ang->Kundma .AND. auf->Matchcode == ang->Matchcode }
bFind := {|| auf->Besda >= ang->Besda  }
If auf->(dbSeek( ang->Kundma+ang->Matchcode ))
	nQty := 0
	nAb := 0
	Do While Eval(bWhile) .AND. ! Eval(bFind)
		If Eval(bFind)
			If nAB == auf->AbNr
				nQty += auf->VkQty
			Else
				nAb := auf->Abnr
				nQty := auf->VkQty
			Endif
		Endif
		If nQty >= ang->VKQty*0.8
			Exit
		Endif
		auf->(dbSkip())
	Enddo
    If Eval(bWhile) .AND. Eval(bFind) /*.AND. nQty >= ang->VKQty*0.8*/
//    	@ 06,40 SAY "Bestellt am "
		@ 13,20 SAY DToC( auf->Besda ) COLOR If(nQty >= ang->VKQty*0.8,"N/G*",SetColor())
		@ 13,29 SAY "("+LTrim(Transform(auf->VkQty,Me(art->me)))+" "+art->me+")"
    Endif
Endif

@ nT+nX+1,02 TO nT+nX+1,62
@ nT+nX+1,03 SAY "[ Notizen ]"
oBrowse := TalkBrowse(nT+nX+2,02,MaxRow()-1,62,.F.)
Select("nts")
LOCATE FOR nts->Betreff == "ANG" .AND. nts->Nummer == ang->Angnr WHILE nts->Matchcode == ang->Kundma .AND. nts->Group == "K"
nts->(dbSetOrder( 1 ))
oBrowse:lBox := .F.
oBrowse:ForBlock := {|| nts->Betreff == "ANG" .AND. nts->Nummer == ang->angnr }
oBrowse:AddKey(Asc("B"),bDisplayApr)
oBrowse:AddKey(Asc("b"),bDisplayApr)

@ 04,01 TO MaxRow(),63
@ 04,02 SAY "[ Angebot "+lTrim(Str(ang->angnr))+" Pos "+Ltrim(Str(ang->itmnr))+" ]"
//IsApproved(cType,nNo,tLastChange,lWaitApproval,nRec)
SetColor(c_Six)
oBrowse:eventloop()

/*   DO WHILE .T.
      nKey := Sinkey(0)
      IF Chr(nKey) $ "Bb"
         Eval(bDisplayApr)
      ELSE
         EXIT
      ENDIF
   ENDDO
  */