LOCAL lDebug := .F. //Tr_Getini(28) == 9
LOCAL aBrakes,hPrices,hPriceList
LOCAL bTimeBlock

NetUse("option","op",.F.,0)
//nOrder := art->(IndexOrd())
hReqInc := GetProductRequirementAndIncoming(art->artikelnr)
NetUse("engkund","ku",.F.,0)
NetUse("engtext2","tx",.F.,0)
NetUse("artkund","aku",.F.,0)
NetUse("artlief","ali",.F.,0)
NetUse("engauf","auf",.F.,0)
NetUse("cat","cat",.F.,0)
NetUse("manufact","man",.F.,0)

oArt := Artikel():New(.F.)
oArt:Load(art->Artikelnr)

SetColor( c_five )
//DISPBEGIN()
//a := 1/0
nLeft  := 00
nRight := 89
nC1 := nLeft+2
nC2 := 51

Box( 00, nLeft, MaxRow(), nRight,,.T.,2) // "�ͻ���Ⱥ ")
DispBox( 02, nC2-2, 33, nC2-2, 1 )
//@ 08,nC2-2 SAY Chr(192)
DispBox( 33, nC2-2, 33, nRight-2, 1 )
@ 33,nC2-2 SAY Chr(192)

cDev := Replicate(Chr(196),nC2-nC1-2)

#define HB_GTI_DISPIMAGE        71

bAfterKey := {|| .T. }
cImageFile := ""
If cat->(dbSeek(art->Artikelnr))
	If ! Empty(cat->Image)
		cImageFile := Trim(Tr_Getini(1))+"\images\catalog\"+Trim(cat->Image)
		If File( cImageFile )
 	 		//bAfterKey := {|| Wvt_DrawImage( 02,nRight-9,0,nRight-1, cImageFile ) }
 	 		IF Tr_Getini(28) == 9
// 	 		    HB_GTINFO(HB_GTI_DISPIMAGE,cImageFile)
 	 		ENDIF
 	 	Endif
  	Endif
Endif
notiz := .T.

@ 00,nC1-1 SAY "["
Bold(00, nC1,t("Artikel: ")+Trim(ART->matchcode))
DevOut("]")
bold( 01,nC1,Trim(ART->artikel),0 )

cText := t("Artikelnr.:") + " " + LTrim(STR( ART->artikelnr ))
@ 00,nRight-Len(cText)-2 SAY "["
bold( 00,nRight-Len(cText)-1,cText,0 )
DevOUt("]")

IF art->Obsolete
   @ 00,nC1+30 SAY t(" A B G E K � N D I G T ") COLOR "N/GR*"
ENDIF


//IF(!EMPTY( ART->INFO ),EVAL({|| DEVPOS(04,COL()+1),DEVOUT("&",C_TWO) }),"")
DevPos( 00, nC1+20 )
DevOut( IF(art->Sperren .OR. art->Inventur,"GESPERRT",""), "W+*" )

//@ 03,nC1 SAY msb[24] + ART->such
//DevPos( 05, nC1 )

cMeTr := Me(art->me)
cCur := Currate(art->Money,"X")


@ 03,nC1 SAY cDev
@ 03,nC1+1 SAY "[Best�nde]"

@ 04,nC1 SAY Pad("Bestand",13)+":" + art->(GetFormatedBestand()) //Transform( ART->bestand,cMeTr) + " " + ART->me

IF art->Manufactur == 1
   NetUse("liefstock","lsto")
   IF lsto->(dbSeek( Pad("WALDOM",8)+Str(art->Artikelnr,6) ))
      @ 05,nC1 SAY Pad(" 7 Tage",13)+": "+PadL(Transform(lsto->Stock,cMeTr),11)+" "+art->Me
      @ 06,nC1 SAY Pad("14 Tage",13)+": "+PadL(Transform(lsto->DelQty,cMeTr),11)+" "+art->Me
   ENDIF
ENDIF

@ 11,nC1 SAY cDev

@ 12,nC1 SAY msb[26]+LTrim(Str(hReqInc["income"],6,0))
@ 13,nC1 SAY msb[27]+LTrim(Str(hReqInc["requirement"],6,0))
@ 14,nC1 SAY "Meldebestand : "+ LTrim(Transform( ART->mindest, cMeTr ))
//DevPos( 17, nC1 )
//DevOut( msb[29] + STR( ART->letzte_vk/Currate("E","V"),8,2 )+" "+Currate("E","X") + " / " + LTrim(STR( ART->vkpe )) )
cEK := IF(art->Bezug>=5,"HK","EK")

//@ 18,nC1 SAY msb[30] + LTrim(STR( ART->vkpreis2 )) + "/" + LTrim(STR( ART->vkpe ))
@ 16,nC1 SAY  Pad(t("Netto "+cEk),13)+": " + LTrim(STR( ART->netprice ))
IF art->Rabatt != 0
   @ 16,Col()+1  SAY "("+t("abzgl.")+" "+ Ltrim(STR( ART->rabatt ))+"%)"
ENDIF
@ 17,nC1 SAY Pad(t("Letzte "+cEk),13)+": " + LTrim(STR( ART->letzte_ek,8,2 )) +" "+cCur
If art->Money != "E"
	@ 17,Col()+1 SAY "("+LTrim(Str(art->letzte_ek*Currate(art->Money,"E")/Currate("E","E"),8,2))+" "+Currate("E","X")+")"
Endif
 @ 17,Col()+1 SAY "/ "+LTrim(Str(art->pe))

nAvPreis := 0
/*If art->Bezug >= 5
	nAvPreis := StCalc(art->Artikelnr,5,999,.T.,Date(),hManuSplit)
Else
	nAvPreis := Get ProductAvgBuyPrice(art->Artikelnr,Date())
Endif*/

   @ 18,nC1 SAY Pad(t("D/S "+cEk),13)+": "+LTrim(STR( oArt:GetAvgBuyPrice(Date()/*,Tr_Getini(28)==9*/) ))+" EUR" //+cCur
   //

@ 20,nC1 SAY Pad(t("Besch.zeit"),13) + ": " + LTrim(STR( IF(art->LZ==0,12,ART->lz) ))+" Wochen"

@ 22,nC1 SAY msb[36]+LTrim(Str(hReqInc["avgrequirement"]))
@ 22,nC1+(nC2-nC1)/2 SAY HB_AnsiToOem("Vorhersage   : ")+LTrim(Str(hReqInc["forecast"]))
@ 23,nC1 SAY "Kunden (12 M): "+LTrim(Str(hReqInc["cust_count"]))
@ 25,nC1 SAY HB_AnsiToOem("Auftragspos. : ")+LTrim(Transform(hReqInc["order_count"],cMeTr))
@ 26,nC1 SAY HB_AnsiToOem("Gr��te Pos.  : ")+LTrim(Transform(hReqInc["maxorder"],cMeTr))

@ 27,nC1+15 SAY "Gesamt"
@ 27,nC1+22 SAY Str(Year(Date()),4)
@ 27,nC1+29 SAY Str(Year(Date())-1,4)
@ 27,nC1+36 SAY Str(Year(Date())-2,4)
hMonthData := NIL
aYears := {{"bought"=>0,"sold"=>0},{"bought"=>0,"sold"=>0},{"bought"=>0,"sold"=>0}}

FOR EACH hMonthData IN hReqInc["months"]
   nYear := Val(LTrim(Left(hMonthData:__enumKey(),5)))
   IF nYear <= Year(Date()) .AND. Year(Date())-nYear < 3
//      ? nYear,Year(Date())-nYear+1,ValToPrg(hMonthData),ValToPrg(aYears[Year(Date())-nYear+1])
      aYears[Year(Date())-nYear+1]["sold"] += hMonthData["sold"]
      aYears[Year(Date())-nYear+1]["bought"] += hMonthData["bought"]
   ENDIF
NEXT
@ 28,nC1 SAY "EK Menge     : "+LTrim(Transform(art->gelqty,cMeTr))
If HHasKey(hReqInc,"total_bought")
	@ 29,nC1 SAY "VK Menge     : "+LTrim(Transform(hReqInc["total_bought"],cMeTr))
Endif
FOR nX := 1 TO 3
   @ 28,nC1+15+7*nX SAY +LTrim(Transform(aYears[nX]["bought"],cMeTr))
   @ 29,nC1+15+7*nX SAY +LTrim(Transform(aYears[nX]["sold"],cMeTr))
NEXT
@ 02,nC2 SAY "Gewicht : " + Ltrim(Str(ART->gewicht))+"g"
@ 03,nC2 SAY "VPE     : "+LTrim(Transform(art->vpe,cMeTr))
DevPos( 07, nC2 )
@ 04,nC2 SAY "Bezug   : "+Ltrim(STR( ART->bezug ))

@ 06,nC2-1 SAY Replicate(Chr(196),nRight-nC2)

//nLetzte := if(! EMPTY( art->table ),art->(Prices(06,nC2-1)),0)
aPrices := {}
IF ! Empty(art->Table)
   DisplayPrices(06,nC2-1,art->Artikelnr,,,,Date(),,Chr(196)+"[ PREISSTAFFEL ]",@aPrices)
   IF art->Table == 44
      @ 06,nC2+15 SAY t("GP") COLOR "B/G*"
      @ 06,nC2+17 SAY " ]"
   ENDIF
ENDIF
//KuData(20,nC2-1,28,nLetzte)
IF art->Manufactur == 1 .AND. lsto->(dbSeek( Pad("WALDOM",8)+Str(art->Artikelnr,6) ))
   //DisplayPrices(06,nC2+20,art->Artikelnr,0,1,ku->Money,Date(),ku->Kunde,"[ "+ku->Kunde+" ]")
   @ 07,nC2+20 SAY "WALDOM"
   oArtikel := Artikel():New(.F.)
   oArtikel:Load(art->Artikelnr)
   aPrices := oArtikel:GetSellPrices(Date())
   FOR nX := 1 TO Len(aPrices)
      nPrice := nPe := 0
      GetBuyPrice( Pad("WALDOM",8), art->Artikelnr, aPrices[nX,1], @nPrice, @nPE )
      nMargin := 0.25
      @ 07+nX,nC2+20 SAY IF( aPrices[nX,2]/art->VkPe >= nPrice/nPe/(1-nMargin) ,"Y",LTrim(str(nPrice/nPe/(1-nMargin)*art->VkPe,9,2)))
   NEXT
ELSEIF Select("ku") != 0 .AND. ku->Group == "K" .AND. Hook("before_get_prices",{art->Artikelnr,art->Table,Date(),ku->Kunde},art->Table) != art->Table
   DisplayPrices(06,nC2+20,art->Artikelnr,0,1,ku->Money,Date(),ku->Kunde,"[ "+ku->Kunde+" ]")
ENDIF
@ 19,nC2-1 SAY Replicate(Chr(196),nRight-nC2)
IF art->Bezug != 5
   @ 20,nC2 SAY "Preise abfragen mit >P<"
ELSE
   NetUse("werkauf","wer")
   NetUse("watime","wat")
   NetUse("jobs","job")
   bTimeBlock := {|lDisp|
      LOCAL cList := "",cScr
      wer->(dbSetOrder( 2 )) // Str(artno)
      wer->(dbSeek( Str(art->Artikelnr,6) ))
      nTotTime := 0
      nTotQty  := 0
      hTotJobs := {=>}
      nT := NIL
      aJob := NIL
      IF wer->Qty > 0
         DO WHILE wer->Artno == art->Artikelnr .AND. ! wer->(EOF())
            wat->(dbSeek( Str(wer->Aufno,6) ))
            nTime := 0
            hJobs := {=>}
            DO WHILE wat->Wanr == wer->Aufno .AND. ! wat->(EOF())
               IF lDisp
                   job->(dbSeek( Str(wat->Job,6) ))
                  cList += Str(wer->Aufno,6)+" "+job->Name+" "+Left(TtoC(SToT(wat->Start)),14)+" "+Left(TtoC(SToT(wat->End)),14)+" "+Str((StoT(wat->End)-StoT(wat->Start))*24*60,6,0)+Chr(13)+Chr(10)
               ENDIF
               nT := (StoT(wat->End)-StoT(wat->Start))*24*60
               nTime += nT
               IF ! HHasKey(hJobs,wat->Job)
                  hJobs[wat->Job] := 0
               ENDIF
               hJobs[wat->Job] += nT
               wat->(dbSkip())
            ENDDO
            IF nTime > 0
               nTotTime += nTime
               nTotQty  += wer->Qty
               FOR EACH nT IN hJobs
                  nJob := nT:__eNumKey()
                  IF ! HHasKey(hTotJobs,nJob)
                     hTotJobs[nJob] := {0,0}
                  ENDIF
                  hTotJobs[nJob][1] += nT
                  hTotJobs[nJob][2] += wer->Qty
               NEXT
            ENDIF
            wer->(dbSkip())
         ENDDO
      ENDIF
      IF lDisp
         cScr := SaveScreen()
         MemoEdit(cList,,,,,.F.)
         RestScreen(,,,,cScr)
      ENDIF
      @ 20,nC2 SAY t("Durschn. Fertigungszeiten")
      @ 21,nC2 SAY t("ges. Baustufe")
      IF nTotQty > 0
         @ 21,nC2+21 SAY Str(nTotTime/nTotQty,5,2)+" min"
      ENDIF
      FOR nX := 1 TO Len(hTotJobs)
         aJob := HGetValueAt(hTotJobs,nX)
         nJob := HGetKeyAt(hTotJobs,nX)
         job->(dbSeek( Str(nJob,6) ))
         @ 21+nX,nC2 SAY job->Name
         IF aJob[2] > 0
            @ 21+nX,nC2+21 SAY Str(aJob[1]/aJob[2],5,2)+" min"
         ENDIF
      NEXT
   }
   Eval(bTimeBlock,.F.)
ENDIF



man->(dbSeek( Str(art->Manufactur,5) ))
@ 30,nC1 SAY "Hersteller   : "+man->Short

@ 31,nC1 SAY "Zolltarifnr. : "+art->KnCode
@ 32,nC1 SAY "Ursprungsland: "+Trim(GetCountryName(art->Ursprung))
@ 33,nC1+15 SAY "("+If(ArtHasValidLE(art->Artikelnr),"","nicht ")+"pr�ferenzbeg�nstigt)"


@ 34,nC1 SAY msb[33] + "("+ART->gruppe+")"
ArtGrup(ART->gruppe,34,nC1+22)

//art->(dbSetOrder(nOrder))
@ 35,nC1 SAY "Zeichnungsnr.: "+Trim(art->Zeichnung)+If(!Empty(art->ZeichIndex)," Ind. "+Trim(art->ZeichIndex),"")
IF ! Empty(art->Zeichnung)
	cDrawingFile := MBaseRun(Trim(Tr_Getini(1))+"\run\getdrawing")
	IF ! Empty(cDrawingFile)
		@ Row(),Col()+1 SAY t("(�ffnen mit >Z<)")
	ENDIF
ENDIF
@ 36,nC1 SAY Replicate(Chr(196),nRight-nC1-1)
nY := tx->(DispText(art->textnr,37,nC1,78,MaxRow()-37-1,.F.))
OptDisp(nY,nC1,MaxRow()-nY,c_five)

IF art->Bezug != 5
   nR := 07
   ali->(dbSetOrder( 1 ))
   If ali->(dbSeek(Pad("RS",8)+Str(art->Artikelnr,6))) .AND. ! Empty(ali->artlief)
   	@ nR,nC1 SAY "RS"
   	@ nR,nC1+13 SAY ": abfragen mit >LEER<"
   	nR++
   Endif
   If ali->(dbSeek(Pad("FARNELL",8)+Str(art->Artikelnr,6))) .AND. ! Empty(ali->artlief)
         	@ nR,nC1 SAY "Farnell"
   	@ nR,nC1+13 SAY ": abfragen mit >LEER<"
   	nR++
   Endif
   /*If ali->(dbSeek(Pad("ETTINGER",8)+Str(art->Artikelnr,6))) .AND. ! Empty(ali->artlief)
         	@ nR,nC1 SAY "Ettinger"
   	@ nR,nC1+13 SAY ": abfragen mit >LEER<"
   	nR++
   Endif*/
   If ali->(dbSeek(Pad("ELIMEC",8)+Str(art->Artikelnr,6)))
         	@ nR,nC1 SAY "Elimec"
         	@ nR,nC1+13 SAY ": abfragen mit >LEER<"
         	nR++
   Endif
   If ali->(dbSeek(Pad("MOUSER",8)+Str(art->Artikelnr,6)))
         	@ nR,nC1 SAY "Mouser"
         	@ nR,nC1+13 SAY ": abfragen mit >LEER<"
         	nR++
   Endif
ENDIF

nKey := 0
DO WHILE nKey != 27
   Eval(bAfterKey)
   nKey := SInkey(0,bAfterKey)
   If art->Bezug != 5 .AND. LastKey() == 32
   	FOR nX := 07 TO 10
   		@ nX,nC1+14 SAY Space(33)
   	NEXT
   	nR := 07
   	If ali->(dbSeek(Pad("RS",8)+Str(art->Artikelnr,6))) .AND. ! Empty(ali->artlief)
   		@ nR,nC1+13 SAY ": lade..."
   		nQty := GetLiefStock("RS",art->Artikelnr)

   		@ nR,nC1+15 SAY Space(8)
   		If nQty >= 0
   			@ nR,nC1+15 SAY Transform(nQty,cMeTr)
   		Elseif nQty == -2
   			@ nR,nC1+15 SAY "Nicht im Sortiment"
   		Else
   			@ nR,nC1+15 SAY "Fehler!"
   		Endif
   		nR++
   	Endif
   	If ali->(dbSeek(Pad("FARNELL",8)+Str(art->Artikelnr,6))) .AND. ! Empty(ali->artlief)
   		@ nR,nC1+13 SAY ": lade..."
   		nQty := GetLiefStock("FARNELL",art->Artikelnr)
   		@ nR,nC1+15 SAY Space(10)
   		If nQty >= 0
   			@ nR,nC1+15 SAY Transform(nQty,cMeTr)
   		Elseif nQty == -2
   			@ nR,nC1+15 SAY "Nicht im Sortiment"
   		Else
   			@ nR,nC1+15 SAY "Fehler!"
   		Endif
   		nR++
   	Endif    
      /* If ali->(dbSeek(Pad("ETTINGER",8)+Str(art->Artikelnr,6))) .AND. ! Empty(ali->artlief)
   		@ nR,nC1+13 SAY ": lade..."
   		nQty := GetLiefStock("ETTINGER",art->Artikelnr)
   		@ nR,nC1+15 SAY Space(10)
   		If nQty >= 0
   			@ nR,nC1+15 SAY Transform(nQty,cMeTr)
   		Else
   			@ nR,nC1+15 SAY "Fehler!"
   		Endif
   		nR++
   	Endif*/
   	If ali->(dbSeek(Pad("ELIMEC",8)+Str(art->Artikelnr,6)))
   		@ nR,nC1+13 SAY ": lade..."
   		nQty := GetLiefStock("ELIMEC",art->Artikelnr)
   		@ nR,nC1+15 SAY Space(10)
   		If nQty >= 0
   			@ nR,nC1+15 SAY Transform(nQty,cMeTr)
   		Else
   			@ nR,nC1+15 SAY "Fehler!"
   		Endif
   		nR++
   	Endif
   	If ali->(dbSeek(Pad("MOUSER",8)+Str(art->Artikelnr,6)))
   	   @ nR,nC1+13 SAY ": lade..."
   		nQty := GetLiefStock(Pad("MOUSER",8),art->Artikelnr)
   		@ nR,nC1+15 SAY Space(10)
   		If nQty >= 0
   			@ nR,nC1+15 SAY Transform(nQty,cMeTr)
   		Else
   			@ nR,nC1+15 SAY "Fehler!"
   		Endif
   	Endif
   	//Eval(bAfterKey)
   	//SInkey(0,bAfterKey)
   ELSEIF art->Bezug != 5 .AND.  Upper(Chr(nKey)) == "P"
      IF lDebug
         aCompet := {"Mouser"}
      ELSE
         aCompet := {"RS","Farnell","Ettinger","Conrad","TME","Mouser","Reichelt","Schukat"}
      ENDIF

      nR := 1
      nT :=  20
      @ nT,nC2 CLEAR TO nT+12,nC2+36
      @ nT,nC2 SAY "Preise werden geladen..."

      aBrakes := {}
      hPriceList := {=>}

      FOR nX := 1 TO Len(aCompet)
         ali->(dbSeek(Pad(Upper(aCompet[nX]),8)+Str(art->Artikelnr,6)))
         IF aCompet[nX] $ "TME Schukat" .OR. (ali->(Found()) .AND. ! Empty(ali->artlief))
            @ nT+nR,nC2 SAY aCompet[nX]
            //hPrices := NIL
            hPrices := MBaseRun(Trim(Tr_Getini(1))+"\run\prices\"+aCompet[nX],{art->Artikelnr,ali->Artlief,art->Matchcode})
            @ nT+nR,nC2+9 SAY Space(24)
            IF ValType(hPrices) != "H" .OR. Len(hPrices) == 0
               @ nT+nR,nC2+9 SAY "FEHLER!"
//               aPrices[nX] := {=>}
            ELSE
               @ nT+nR,nC2+9 SAY LTrim(Transform(HGetKeyAt(hPrices,1),cMeTr))+" - "+LTrim(Str(HGetValueAt(hPrices,1),12,2))+" | "+LTrim(Transform(HGetKeyAt(hPrices,Len(hPrices)),cMeTr))+" - "+LTrim(Str(HGetValueAt(hPrices,Len(hPrices)),12,2))
               FOR nY := 1 TO Len(hPrices)
                  IF AScan(aBrakes,HGetKeyAt(hPrices,nY)) == 0
                     Aadd(aBrakes,HGetKeyAt(hPrices,nY))
                  ENDIF
               NEXT
               hPriceList[aCompet[nX]] := hPrices
            ENDIF
            nR++
         ENDIF
      NEXT
      ASort(aBrakes)
       //Inkey(0,128)
      /*IF HHasKey(hPriceList,"Ettinger")
         nKey := HGetKeyAt(hPriceList["Ettinger"],Len(hPriceList["Ettinger"]))
         IF nKey != ATail(aBrakes)
            hPriceList["Ettinger"][Atail(aBrakes)] := hPriceList["Ettinger"][nKey]
            HDel(hPriceList["Ettinger"],nKey,.T.)
         ENDIF
      ENDIF*/

      @ nT,nC2 CLEAR TO nT+12,nC2+36

      nLen := Int(36/(Len(hPriceList)+1))

      nMaxLen := 1
      FOR nY := 1 TO Len(aBrakes)
         nMaxLen := Max(nMaxLen,Len(LTrim(Transform(aBrakes[nY],cMeTr))))
         FOR EACH hPrices IN hPriceList
            IF HHasKey(hPrices,aBrakes[nY])
//               Alert( hPrices:__enumKey()+ Str(aBrakes[nY])+" "+Str(Len(LTrim(Str(hPrices[aBrakes[nY]],12,2)))) )
               nMaxLen := Max(nMaxLen,Len(LTrim(Str(hPrices[aBrakes[nY]],12,2))))
            ENDIF
         NEXT
      NEXT

      IF nLen < nMaxLen+1
         nLen := nMaxLen+1
         nC2 := nC2+36-nLen*(Len(hPriceList)+1)
         @ nT-1,nC2-1 TO nT+13,maxCol()-1 //Chr(179)
         @ nT-1,MaxCol()-1 CLEAR TO nT+13,MaxCol()-1
         @ nT,nC2 CLEAR TO nT+12,maxCol()-2 //Chr(179)

      ENDIF


      FOR nY := 0 TO Len(aBrakes)
         IF nY != 0
            @ nT+nY,nC2 SAY LTrim(Transform(aBrakes[nY],cMeTr))
         ENDIF
         FOR EACH hPrices IN hPriceList // nX := 1 TO Len(aCompet)
            IF nY == 0
               @ nT+nY,nC2+(hPrices:__enumIndex())*nLen SAY Pad(hPrices:__enumKey(),nLen-1)
            ELSEIF HHasKey(hPrices,aBrakes[nY])
               nP := RAScan(aPrices,{|x| x[1] <= aBrakes[nY] })
               IF nP == 0
                  nP := 1
               ENDIF
               @ nT+nY,nC2+(hPrices:__enumIndex())*nLen SAY LTrim(Str(hPrices[aBrakes[nY]],12,2)) COLOR IF(Len(aPrices) > 0 .AND. nP > 0 .AND. aPrices[nP,2]/art->VkPe > hPrices[aBrakes[nY]],"R+/R",c_five)
//               @ nT+nY,nC2+(hPrices:__enumIndex())*nLen-3 SAY "("+Str(nP,1)+")"
            ENDIF
         NEXT
      NEXT

   ELSEIF Upper(Chr(nKey)) == "Z" .AND. ! Empty(art->Zeichnung) .AND. ! Empty(cDrawingFile)
    	WAPI_ShellExecute(,"open",cDrawingFile)
   ELSEIF Upper(Chr(nKey)) == "T" .AND. ValType(bTimeBlock) == "B"
      Eval(bTimeBlock,.T.)
   Endif
ENDDO