#ifndef __XHARBOUR__
	#xtranslate ShellExecute([<x,...>])        => Wapi_ShellExecute(<x>)
#endif

LOCAL lFin := AScan({9,34},Tr_Getini(28)) != 0
LOCAL bUpdCredit := {|| NIL }
LOCAL bOpenCreditReport := {|| NIL }
LOCAL oReport

NetUse("angebot","ang",.F.,0)
ang->(dbSetOrder( 2 ))
NetUse("notes","nts",.F.,0)
NetUse("contacts","conts",.F.,0)
conts->(dbSetOrder(1))

//hTurnover := If(ku->Group=="K",GetCustomerTurnover(ku->kunde),{"open"=>ku->open,"current"=>ku->Turnover,"last"=>ku->turnoverol,"last3"=>0,"total"=>ku->turnoverto})
aAngebot := GetCustomerOpenEnquiries(ku->Kunde)

SetColor(c_five)

nTop := 03
nLeft := 03
nBottom := 30
nRight := 80
//TxtClear()
@ nTop,nLeft CLEAR TO nBottom,nRight
@ nTop,nLeft TO nBottom,nRight

If ! Empty(ku->KuSchutz)
	lBlink := SetBlink(.T.)
	nRec := ku->(Recno())
	nOrder := ku->(dbSetOrder( 8 ))
	If ku->(dbSeek( Str( ku->KuSchutz ,6) ))
		DispBox(nTop,nLeft,nBottom,nRight,Replicate(Chr(219),4),"GR+")
		@ nBottom,nLeft+1 SAY Pad(" "+t("GESCH�TZT F�R:")+" "+Trim(ku->Name1)+" "+ku->Name2,nRight-nLeft-1) COLOR "N/GR*"
	Endif
	ku->(dbSetOrder( nOrder ))
	ku->(dbGoTo( nRec ))
Endif



@ nTop,nLeft+2 SAY "[" + ku->kunde + "]"
@ nTop,nRight-Len(LTrim(Str(ku->Nummer,6)))-3 SAY "[" + LTrim(Str(ku->Nummer,6)) + "]"

IF(ku->group == "K", bold( nTop+1,nLeft+2,msb[4],0 ),IF(ku->group == "L", bold( nTop+1,nLeft+2,msb[5],0 ),bold( nTop+1,7,msb[6]+ku->group+"    ",0 )))
ku->( yesnotes() )
notiz := .T.


//Top Left
DevPos( nTop+2, nLeft+2 )
DevOut( ku->name1 )
DevPos( nTop+3, nLeft+2 )
DevOut( ku->name2 )
DevPos( nTop+4, nLeft+2 )
DevOut( ku->Street )
DevPos( nTop+5, nLeft+2 )
DevOut( TRIM( ku->plz ) + " " + ku->town )
DevPos( nTop+6, nLeft+2 )
DevOut( GetCountryName(ku->CountryIso) )

bold(nTop+8,nLeft+2,msb[7] + ku->telefon,0)

@ nTop+9, nLeft+2 SAY "EMAIL    " + Pad(ku->Email,27)
@ nTop+10, nLeft+2 SAY msb[9] + ku->telefax

@ nBottom-9,nLeft+2 SAY Pad(SKONTVA(ku->Skonto,"D",,,.F.),nRight-nLeft-2)

DevPos( nTop+1, 44 )
DevOut( if(ku->group = "L",msb[10] + ku->kundennr,msb[11] + ku->kundennr) )
//DevPos( nTop+2, 44 )
//DevOutPict( msb[12] + ku->bank, "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" )
//DevPos( nTop+3, 44 )
//DevOut( msb[13] + ku->konto )
DevPos( nTop+2, 44 )
DevOut( msb[14] + STR( ku->charge ) )

@ nTop+5,44 SAY "Umsatz abfragen mit >LEER<"

@ nBottom-7, nLeft+1 TO nBottom-7,nRight-1 //divider
DevPos( nBottom-7, nLeft+2 ); DevOut( " "+msb[17]+" " )

lExit := .F.
nX := 0
Do While ! lExit
	If nX > 0 .OR. ku->Group == "K"//space

@ nTop+5,44 SAY "Daten werden gesammelt...  "
hTurnover := If(ku->Group=="K",GetCustomerTurnover(ku->kunde),GetSupplierTurnover(ku->Kunde))

If ku->Group == "K"
	cType := ""
	If hTurnover["current"]+hTurnover["last"] > 0
		cType := "KUNDE"
	Elseif hTurnover["total"] > 0
		cType := "EHEMALIGER KUNDE"
	Elseif ang->(dbSeek( ku->Kunde ))
	    cType := "INTERESSENT"
	Elseif nts->(dbSeek(ku->Kunde+ku->Group,.T.))
		cType := "KONTAKTIERT"
	Else
		cType := "KEIN KONTAKT"
	Endif
	@ nTop,44 SAY "[ "+cType+" ]"
Endif

@ nTop+3,44 TO nTop+3,76
@ nTop+3,45 SAY " Umsatz "
DevPos( nTop+4, 44 )
DevOut( "Aktuell:" +" EUR "+ (STR( hTurnover["current"],12,2)) )
DevPos( nTop+5, 44 )
DevOut( "Vorjahr:" +" EUR "+(STR( hTurnover["last"],12,2 )) )
@ nTop+6,44 SAY "3-Jahre: EUR "+(Str(hTurnover["last3"],12,2))
//LTrim(STR( ku->turnoverol )) )
@ nTop+7,44 SAY "Gesamt : EUR "+(Str(hTurnover["total"],12,2))
@ nTop+8,44 TO nTop+8,76
If ku->Group == "K"
	@ nTop+09,44 SAY "Offene Auftr�ge: EUR "+(Str(GetCustomerOpenOrders(ku->kunde),12,2))
	@ nTop+10,44 SAY "Offene Angebote: EUR "+(Str(aAngebot[2],12,2))
	@ nTop+11, 44 SAY "Limit  EUR: " + LTRIM(STR(GetCustomerCreditLimit(ku->Kunde),13,0))
	@ nTop+12, 44 SAY "Offen  EUR: " + LTRIM(STR(hTurnover["open"],12,2))
	@ nTop+13, 44 SAY "Kredit "+Currate(ku->Money,"X")+": " + LTRIM(STR(GetCustomerCredit(ku->Kunde),12,2))
	nAgedTime := 0
	nDays := GetCustomerPayTime(ku->Kunde,@nAgedTime)
	@ nBottom-8, nLeft+2 SAY "Durchschnittliche gewichtete Zahldauer: "+LTrim(Str(nDays,3,0))+" Tag"+If(nDays!=1,"e","")
	If ValType(nAgedTime) == "N"
		?? " (Vorhersage: "+LTrim(Str(nAgedTime,3,0))+")"
	Endif
	If trVer >= "5.07"
		hAct := GetCustomerActivityIndex(ku->Kunde)
		@ nBottom-10,nLeft+2 SAY "Aktivit�t : "+LTrim(Str(hAct["avg"]*100,5,2))+" "+LTrim(Str(hAct["weighted"]*100,10,2))
	Endif
	If ku->rep !=0
		@ nBottom-11,nLeft+2 SAY t("Au�endienst")+": "+RepGetName(ku->Rep)
	Endif
	@ nBottom-12,nLeft+2 SAY "Angelegt am: "+DToC(ku->K_Seit)

	bDisplayCreditWorth := {||
      oReport := CS_GetCompanyReportFromArchive(ku->Nummer)
      IF oReport != NIL .AND. oReport:oRoot != NIL
         oIter := TXmlIteratorScan():New(oReport:oRoot)
         oNode := oIter:Find("DECurrentRating")
         @ nTop+14, 44 SAY "Rating    : "+IF(oNode!=NIL,oNode:cData,"-")
         @ nTop+15,44  SAY "Status    : "
         oIter:Rewind()
         oNode := oIter:Find("CompanyStatus")
         IF oNode != NIL
            cStatus := oNode:GetAttribute("Code")
            hStatus := {"Active"=>"aktiv","NonActive"=>"nicht aktiv","Pending"=>"schwebend"}
            IF HHasKey(hStatus,cStatus) .AND. oNode:cData $ "active aktiv"
               @ nTop+15,56 SAY hStatus[cStatus]
            ELSE
               @ nTop+15,56 SAY "unbekannt"
            ENDIF
         ENDIF
   /*         IF Trim(ku->Kunde) == "TESTXX"
   //         BusinessName
            oIter:Rewind()
   //            CS_DownloadAndSavePdfReport(oIter:Find("Number"):cData,2,ku->Nummer)
            TxtBox("Loading report")
            oSoap := CreditSafe()
            oReport := CS_GetCompanyReport(oSoap,oIter:Find("Report"):GetAttribute("CompanyId"),2)
            txtClear()
            CS_SaveReport(ku->Nummer,oReport)
         ENDIF */
      ELSEIF oReport != NIL
         Alert("Report not readable")
      ENDIF
      RETURN NIL
   }
   Eval(bDisplayCreditWorth)
   
   IF lFin .AND. oReport != NIL
      bUpdCredit := {||
         NetUse("creditsafe","cs")
         IF cs->(dbSeek( Str(ku->Nummer,6) )) .AND. ! Empty(cs->ID)
            TxtBox("Auskunft wird aktualisiert")
            oSOAP := CreditSafe()
            oReport := CS_GetCompanyReport(oSoap,cs->ID,3)
            IF oReport == NIL
               Tr_MsgBox("Fehler beim laden...")
            ELSE
               IF Empty(CS_SaveReport(ku->Nummer,oReport))
                  Tr_MsgBox("Keine neuen Daten vorhanden")
               ELSE
                  Tr_MsgBox("Daten aktualisiert")
               ENDIF
            ENDIF
            TxtClear()
         ENDIF

      }

      bOpenCreditReport := {||
         LOCAL aFiles := GetArchiveFiles({"KA"=>ku->Nummer})
         IF Len(aFiles) > 0
            WAPI_ShellExecute(,"open",Atail(aFiles)[6])
         ENDIF
      }
      @ nTop+16,44 SAY "Auskunft anzeigen >A<"
   ENDIF
Endif
If ku->Group == "L"
	@ nTop+6,57 SAY Str(hTurnover["last3"],12,2)
	@ nTop+7,57 SAY Str(hTurnover["total"],12,2)

	@ nTop+9,44 SAY  "Offene Best.: EUR "+(Str(hTurnover["open"],12,2))
	@ nTop+10,44 SAY "WE ohne Rechnung"
	@ nTop+11,44 SAY "     Aktuell: EUR "+(Str(hTurnover["unbilled_current"],12,2))
	@ nTop+12,44 SAY "     Vorjahr: EUR "+(Str(hTurnover["unbilled_last"],12,2))

	If HHasKey(hTurnover,"months")
		SET PRINTER TO (Trim(Tr_Getini(1))+"\export\"+Trim(ku->kunde)+"_turnover.csv")
		SET PRINTER ON
		SET CONSOLE OFF
		nY := 1
		nCur := Currate(ku->Money,"E")
		Do While nY <= Len(hTurnover["months"])
			nYear := HGetKeyAt(hTurnover["months"],nY)
			nMonth := 1
			cBook := ""
			cBill := ""
			Do While nMonth <= 12
				cBook += Chr(59)+StrTran(Ltrim(Str(hTurnover["months"][nYear][nMonth]["bookings"]/nCur,12,2)),".",",")
				cBill += Chr(59)+StrTran(Ltrim(Str(hTurnover["months"][nYear][nMonth]["billings"]/nCur,12,2)),".",",")
				nMonth++
			Enddo
            ? str(nYear,4)+" bookings"+cBook
            ? str(nYear,4)+" billings"+cBill
			nY++
		Enddo
		SET PRINTER TO
		SET PRINTER OFF
		SET CONSOLE ON
	Endif 


Endif
	Endif

	conts->(dbSeek( Str(ku->Nummer,6),.T. ))
	If conts->address == ku->Nummer .AND. conts->Active
		oBrowse := conts->(TBrowseTr():New(nBottom-6,nLeft+2,nBottom-1,nLeft+30))
		oBrowse:NewColumn( Nil, {|| Pad(conts->Name,36)  } )
	 	oBrowse:lBox := .F.
	 	oBrowse:lArrow := .F.
	  	oBrowse:WhileBlock := {|| conts->address == ku->Nummer .AND. conts->Active}
	  	//oBrowse:ColorSpec := "W/B+,N+/B+,,N/W,N+/W"
	//  	oBrowse:aKeys := { 27, 32 } //, K_INS, K_ENTER, K_SH_TAB, K_TAB, K_DEL }
	//  	oBrowse:aFun := {{||.F.},{|| .F. }} //,{|| EditContact(.T.)},{|| If(conts->address==nNummer .AND. conts->active,EditContact(.F.),.T.) }, {|| .F. }, {|| .F. }, {|oBrowse| If(conts->address==nNummer,DelContact(),.T.), oBrowse:RefreshAll(),.T. } } //,{||.F.},{|| re->(DispInfo("trd_repos")) } }
		oBrowse:AddKey(32,{||.F.})
		oBrowse:AddKey(13,{|| cLink := If(!Empty(conts->Email),"tic:/"+"/message?to="+Trim(conts->Email),""), If(!Empty(cLink),ShellExecute(NIL, "Open", cLink, "", "", 1),""),.T. })
		oBrowse:AddKey(Asc("A"),bOpenCreditReport)
		oBrowse:AddKey(Asc("a"),bOpenCreditReport)
		oBrowse:AddKey(Asc("U"),bUpdCredit)
		oBrowse:AddKey(Asc("u"),bUpdCredit)
      IF Trim(ku->Kunde) == "TESTXX"
//		oBrowse:AddKey(Asc("c"),{||CS_DownloadAndSavePdfReport(oAddress:GetCargo("id"),2,oAddress:Nummer),.T.})
		ENDIF
		oBrowse:bRestFun := {|| .F. }


	  	nP := nLeft+32
		nW := nRight-nP-9

		//hC := GetContact(conts->Number)

	  	bBlock := {|hC| DevPos(nBottom-4,nP), DevOut("Fax     "+Pad(hC["fullfax"],nW)),DevPos(nBottom-3,nP),DevOut("Email   "+Pad(conts->Email,nW)),DevPos(nBottom-2,nP), DevOut("Abt.    "+Pad(conts->Department,nW)) }
	  	oBrowse:bAnyFun := {|| hC := GetContact(conts->Number), DevPos(nBottom-6,nP), DevOut("Telefon "+Pad(hC["fullphone"],nW)),DevPos(nBottom-5,nP), DevOut("Handy   "+Pad(conts->Mobile,nW)), Eval(bBlock,hC),.T. }

	//
	  	oBrowse:EventLoop()
	Else
		@ nBottom-6,38 SAY "---"
		DO WHILE .T.
   		nKey := Sinkey(0,128)
   		IF Chr(nKey) $ "Aa"
   		    Eval(bOpenCreditReport)
   		ELSEIF Chr(nKey) $ "Uu"
   			 Eval(bUpdCredit)
   		ELSE
   		 EXIT
   		ENDIF
   	ENDDO
	Endif
	If LastKey() != 32 .OR. nX > 0
		lExit := .T.
	Endif
	nX++
Enddo
/*
DevPos( nBottom-6, 38 )
DevOut( "1: "+TRIM(ku->person)+" "+TRIM(ku->telefon1) )
DevPos( nBottom-5, 38 )
DevOut( "2: "+TRIM(ku->person2)+" "+TRIM(ku->telefon2) )
DevPos( nBottom-4, 38 )
DevOut( "3: "+TRIM(ku->person3)+" "+TRIM(ku->telefon3) )
DevPos( nBottom-3, 38 )
DevOut( "4: "+TRIM(ku->person4)+" "+TRIM(ku->telefon4) )
DevPos( nBottom-2, 38 )
DevOut( "5: "+TRIM(ku->person5)+" "+TRIM(ku->telefon5) )
//DISPEND()
SInkey(0,128)*/

#include 'y:\trader30\run\creditsafe.prg'
