NetUse("lagerne","lne",.F.,0)

SetColor(c_five)

DispBox( 01, 04, 08, 60, "�ͻ���Ⱥ ")
//DispBox( 04, 41, 23, 41, 1 )

@ 02,05 SAY art->Matchcode
@ 03,05 SAY art->Artikel
@ 04,05 SAY "Datum..........: "+DToC(mus->Datum)
@ 05,05 SAY "Kontaktperson..: "+GetContact(mus->Person)["name"]
@ 06,05 SAY "Ausgeliefert am: "
If mus->Status >= 3
	lne->(dbSetOrder(1))
	lne->(dbSeek(mus->Nummer))
	@ 06,22 SAY DtoC(lne->Datum)
Else
    @ 06,22	 SAY "-"
Endif
@ 07,05 SAY "Mitarbeiter....: "+Buy(mus->Buyer,.T.)

Sinkey(0,128)